# blogfontend
#一个网页前端界面

最近在研究django 但是看到别人做的博客界面很是漂亮,于是心痒也自己动手做,过程中参考了不少博客,主要链接为:

[tendcode](http://www.tendcode.com/) 

[懿古今](https://www.yigujin.cn/tag/bokeshenghuo/) 

[杨青博客](http://www.yangqq.com/) 

一并致谢!!!


做出的效果大致为下面几个图,基于Bootstrap,差不多入门了css,html,还有个toc(Table of Contents)没有完成,正在考虑是否引入markdown(使用django包),不过原理大致明白,也可能使用Js来实现,后续服务器搭建完成后继续更新


![首页](https://github.com/spygg/blogfrontend/blob/master/screenshot/%E9%A6%96%E9%A1%B5.png  "首页")
![详情页](https://github.com/spygg/blogfrontend/blob/master/screenshot/%E8%AF%A6%E6%83%85%E9%A1%B5.png  "详情页")
![打赏](https://github.com/spygg/blogfrontend/blob/master/screenshot/%E6%89%93%E8%B5%8F.png  "打赏")

下一步工作:

1.创建django博客项目

2.迁移该前端

3.部署

see you!