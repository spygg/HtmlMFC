// MyHtmlView.cpp : implementation file
//

#include "stdafx.h"
#include "MFCHtmlTest1.h"
#include "MyHtmlView.h"


// CMyHtmlView
// CString GetAppPath()
// {
// 	CString strRet;
// 	TCHAR szBuff[_MAX_PATH];
// 	VERIFY(::GetModuleFileName(AfxGetApp()->m_hInstance, szBuff, _MAX_PATH));
// 	strRet = szBuff;
// 	int pos = strRet.ReverseFind('\\');
// 	strRet = strRet.Left(pos);
// 	return strRet;
// }


IMPLEMENT_DYNCREATE(CMyHtmlView, CHtmlView)

BEGIN_DISPATCH_MAP(CMyHtmlView, CHtmlView)
END_DISPATCH_MAP()

BEGIN_MESSAGE_MAP(CMyHtmlView, CHtmlView)
	ON_WM_DESTROY()
	ON_WM_MOUSEACTIVATE()
	ON_WM_SIZE()
	ON_WM_CREATE()
	ON_WM_PAINT()
END_MESSAGE_MAP()

BEGIN_EVENTSINK_MAP(CMyHtmlView, CHtmlView)
//  link can not open,EX auth regist link
//	ON_EVENT(CMyHtmlView, AFX_IDW_PANE_FIRST, DISPID_NEWWINDOW3, CMyHtmlView::OnNewWindow3, VTS_PDISPATCH VTS_PBOOL VTS_UI4 VTS_BSTR VTS_BSTR)
END_EVENTSINK_MAP()

CMyHtmlView::CMyHtmlView()
{
	m_spDoc = NULL;
	isDocumentComplete = false;
	EnableAutomation();// �����Զ���
}

CMyHtmlView::~CMyHtmlView()
{
}

void CMyHtmlView::DoDataExchange(CDataExchange* pDX)
{
	CHtmlView::DoDataExchange(pDX);
}

void CMyHtmlView::OnInitialUpdate()
{
	CHtmlView::OnInitialUpdate();
}

int CMyHtmlView::OnMouseActivate(CWnd* pDesktopWnd, UINT nHitTest, UINT message)
{
	return CWnd::OnMouseActivate(pDesktopWnd, nHitTest, message);
}

void CMyHtmlView::OnDestroy()
{
	if (m_pBrowserApp) 
	{
		m_pBrowserApp.Release();
		m_pBrowserApp = NULL;
	}
	CWnd::OnDestroy();
}

void CMyHtmlView::OnSize(UINT nType, int cx, int cy)
{
	CFormView::OnSize(nType, cx, cy);

	if (::IsWindow(m_wndBrowser.m_hWnd))
	{
		CRect rect;
		GetClientRect(rect);
		LONG lWindows = GetWindowLong(GetParent()->GetSafeHwnd(), GWL_EXSTYLE);
/*		::AdjustWindowRectEx(rect, GetStyle(), FALSE, WS_CLIPSIBLINGS);*/
		::AdjustWindowRectEx(rect, GetStyle(), FALSE, lWindows);

		m_wndBrowser.SetWindowPos(NULL, rect.left, rect.top, 962, 632, SWP_NOACTIVATE | SWP_NOZORDER);

	}
}

int CMyHtmlView::OnCreate(LPCREATESTRUCT lpCreateStruct)
{
	if (CHtmlView::OnCreate(lpCreateStruct) == -1)
		return -1;

	m_DropTarget.Register(this);
	return 0;
}

BOOL CMyHtmlView::CreateFromStatic(UINT nID, CWnd* pParent)
{
	CWnd* pStatic = pParent->GetDlgItem(nID);
	if (pStatic == NULL)
		return FALSE;

	CRect rc;
	pStatic->GetWindowRect(&rc);
	pParent->ScreenToClient(&rc);
	pStatic->DestroyWindow();

	if (!CHtmlView::Create(NULL, NULL, (WS_CHILD | WS_VISIBLE), rc, pParent, nID, NULL))
		return FALSE;

	OnInitialUpdate(); 
	SetSilent(TRUE);//add by wh ,bid pop script dlg  true��ʾ�������浯���Ի���
	return TRUE;
}




BOOL CMyHtmlView::CallJScript(const CString strFunc, _variant_t* pVarResult /*= NULL*/)
{
	CStringArray paramArray;
	return CallJScript(strFunc, paramArray, pVarResult);
}

BOOL CMyHtmlView::CallJScript(const CString strFunc, const CString strArg1, _variant_t* pVarResult /*= NULL*/)
{
	CStringArray paramArray;
	paramArray.Add(strArg1);
	return CallJScript(strFunc, paramArray, pVarResult);
}

BOOL CMyHtmlView::CallJScript(const CString strFunc, const CString strArg1, const CString strArg2, _variant_t* pVarResult /*= NULL*/)
{
	CStringArray paramArray;
	paramArray.Add(strArg1);
	paramArray.Add(strArg2);
	return CallJScript(strFunc, paramArray, pVarResult);
}

BOOL CMyHtmlView::CallJScript(const CString strFunc, const CString strArg1, const CString strArg2, const CString strArg3, _variant_t* pVarResult /*= NULL*/)
{
	CStringArray paramArray;
	paramArray.Add(strArg1);
	paramArray.Add(strArg2);
	paramArray.Add(strArg3);
	return CallJScript(strFunc, paramArray, pVarResult);
}

BOOL CMyHtmlView::CallJScript(const CString strFunc, const CStringArray& paramArray, _variant_t* pVarResult /*= NULL*/)
{
	CComPtr<IDispatch> spScript;
	if (!GetJScript(spScript))
	{
		MessageBox(L"����GetJScrip����ʧ�ܣ�");
		return FALSE;
	}
	CComBSTR bstrFunc(strFunc);
	DISPID dispid = NULL;
	HRESULT hr = spScript->GetIDsOfNames(IID_NULL, &bstrFunc, 1,
		LOCALE_SYSTEM_DEFAULT, &dispid);
	if (FAILED(hr))
	{
		MessageBox(GetSystemErrorMessage(hr));
		return FALSE;
	}

	INT_PTR arraySize = paramArray.GetSize();

	DISPPARAMS dispparams;
	memset(&dispparams, 0, sizeof dispparams);
	dispparams.cArgs = (UINT)arraySize;
	dispparams.rgvarg = new VARIANT[dispparams.cArgs];

	for (int i = 0; i < arraySize; i++)
	{
		CComBSTR bstr = paramArray.GetAt(arraySize - 1 - i); // back reading
		bstr.CopyTo(&dispparams.rgvarg[i].bstrVal);
		dispparams.rgvarg[i].vt = VT_BSTR;
	}
	dispparams.cNamedArgs = 0;

	EXCEPINFO excepInfo;
	memset(&excepInfo, 0, sizeof excepInfo);
	_variant_t vaResult;
	UINT nArgErr = (UINT)-1;  // initialize to invalid arg

	hr = spScript->Invoke(dispid, IID_NULL, 0,
		DISPATCH_METHOD, &dispparams, &vaResult, &excepInfo, &nArgErr);

	delete[] dispparams.rgvarg;
	if (FAILED(hr))
	{
		MessageBox(GetSystemErrorMessage(hr));
		return FALSE;
	}

	if (pVarResult)
	{
		*pVarResult = vaResult;
	}
	return TRUE;
}

// CMyHtmlView diagnostics

#ifdef _DEBUG
void CMyHtmlView::AssertValid() const
{
	CHtmlView::AssertValid();
}

void CMyHtmlView::Dump(CDumpContext& dc) const
{
	CHtmlView::Dump(dc);
}
#endif //_DEBUG


// CMyHtmlView message handlers


void CMyHtmlView::OnNavigateComplete2(LPCTSTR strURL)
{
	// TODO: Add your specialized code here and/or call the base class
	int x = 0;
	CHtmlView::OnNavigateComplete2(strURL);
}


void CMyHtmlView::OnBeforeNavigate2(LPCTSTR lpszURL, DWORD nFlags, LPCTSTR lpszTargetFrameName, CByteArray& baPostedData, LPCTSTR lpszHeaders, BOOL* pbCancel)
{
	// TODO: Add your specialized code here and/or call the base class
	int x = 0;
	CHtmlView::OnBeforeNavigate2(lpszURL, nFlags, lpszTargetFrameName, baPostedData, lpszHeaders, pbCancel);
}


void CMyHtmlView::OnDocumentComplete(LPCTSTR lpszURL)
{
	// TODO: Add your specialized code here and/or call the base class
	CRect rect;
	GetParent()->GetWindowRect(&rect);
	::MoveWindow(GetSafeHwnd(),0,0,rect.Width(),rect.Height(), TRUE);
	CHtmlView::OnDocumentComplete(lpszURL);
	SetScriptDocument();
}


BOOL CMyHtmlView::SetScriptDocument()
{
	CComPtr<IDispatch> spDisp = GetHtmlDocument();
	if (spDisp == NULL)
	{
		ASSERT(FALSE);
		return FALSE;
	}

	m_spDoc = NULL;
	HRESULT hr = spDisp->QueryInterface(IID_IHTMLDocument2, (void**)&m_spDoc);
	if (FAILED(hr))
	{
		MessageBox(L"Failed to get HTML document COM object");
		return FALSE;
	}

	return TRUE;
}

BOOL CMyHtmlView::GetJScript(CComPtr<IDispatch>& spDisp)
{
	if (m_spDoc == NULL)
		return FALSE;

	HRESULT hr = m_spDoc->get_Script(&spDisp);
	ATLASSERT(SUCCEEDED(hr));
	return SUCCEEDED(hr);
}

BOOL CMyHtmlView::GetJScripts(CComPtr<IHTMLElementCollection>& spColl)
{
	if (m_spDoc == NULL)
		return FALSE;

	HRESULT hr = m_spDoc->get_scripts(&spColl);
	ATLASSERT(SUCCEEDED(hr));
	return SUCCEEDED(hr);
}

const CString CMyHtmlView::GetSystemErrorMessage(DWORD dwError)
{
	CString strError;
	LPTSTR lpBuffer;

	if (!FormatMessage(FORMAT_MESSAGE_ALLOCATE_BUFFER | FORMAT_MESSAGE_FROM_SYSTEM,
		NULL, dwError,
		MAKELANGID(LANG_NEUTRAL, SUBLANG_SYS_DEFAULT),
		(LPTSTR)&lpBuffer, 0, NULL))
	{
		strError = "FormatMessage Netive Error";
	}
	else
	{
		strError = lpBuffer;
		LocalFree(lpBuffer);
	}
	return strError;
}


void CMyHtmlView::PostNcDestroy()
{
	// TODO: Add your specialized code here and/or call the base class
	//CHtmlView::PostNcDestroy();
}

BOOL CMyHtmlView::CreateControlSite(COleControlContainer* pContainer, COleControlSite** ppSite, UINT nID, REFCLSID clsid)
{
	*ppSite = new CDocHostSite(pContainer, this);// �����Լ��Ŀ���վ��ʵ��

	return (*ppSite) ? TRUE : FALSE;
}

HRESULT CMyHtmlView::OnGetDropTarget(LPDROPTARGET pDropTarget, LPDROPTARGET* ppDropTarget)
{
	m_DropTarget.SetIEDropTarget(pDropTarget);

	LPDROPTARGET pMyDropTarget;
	pMyDropTarget = (LPDROPTARGET)m_DropTarget.GetInterface(&IID_IDropTarget);
	if (pMyDropTarget)
	{
		*ppDropTarget = pMyDropTarget;
		pMyDropTarget->AddRef();
		return S_OK;
	}

	return S_FALSE;
}

HRESULT CMyHtmlView::OnGetHostInfo(DOCHOSTUIINFO * pInfo)
{
	pInfo->cbSize = sizeof(DOCHOSTUIINFO);
	pInfo->dwFlags = DOCHOSTUIFLAG_THEME | DOCHOSTUIFLAG_NO3DBORDER;
	pInfo->dwDoubleClick = DOCHOSTUIDBLCLK_DEFAULT;

	return S_OK;
}


HRESULT CMyHtmlView::OnGetExternal(LPDISPATCH *lppDispatch)
{
	*lppDispatch = GetIDispatch(TRUE);
	return S_OK;
}

HRESULT CMyHtmlView::OnShowMessage(HWND hwnd, LPOLESTR lpstrText, LPOLESTR lpstrCaption, DWORD dwType, LPOLESTR lpstrHelpFile, DWORD dwHelpContext, LRESULT * plResult)
{
	// ���ڱ���"Microsoft Internet Explorer"����Դ��ʶ
#define IDS_MESSAGE_BOX_TITLE 2213
	//����Shdoclc.dll ��IE��Ϣ������ַ���
	HINSTANCE hinstSHDOCLC = LoadLibrary(TEXT("SHDOCLC.DLL"));
	if (hinstSHDOCLC == NULL)
		return S_FALSE;

	CString strBuf, strCaption(lpstrCaption);
	strBuf.LoadString(hinstSHDOCLC, IDS_MESSAGE_BOX_TITLE);

	// �Ƚ�IE��Ϣ������ַ�����lpstrCaption
	// �����ͬ�����Զ�������滻
	if (strBuf == lpstrCaption)
		strCaption = "LHP HTMLVIEW";

	// �����Լ�����Ϣ������ʾ
	*plResult = MessageBox(CString(lpstrText), strCaption, dwType);

	//ж��Shdoclc.dll���ҷ���
	FreeLibrary(hinstSHDOCLC);

	return S_OK;
}




void CMyHtmlView::OnPaint()
{
	CPaintDC dc(this); // device context for painting
					   // TODO: �ڴ˴�������Ϣ�����������
					   // ��Ϊ��ͼ��Ϣ���� CHtmlView::OnPaint()

}
