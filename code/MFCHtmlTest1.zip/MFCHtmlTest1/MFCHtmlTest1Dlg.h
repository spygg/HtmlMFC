
// MFCHtmlTest1Dlg.h : ͷ�ļ�
//

#pragma once
//#include "MyHtmlView.h"
#include "DemoHtmlView.h"
// CMFCHtmlTest1Dlg �Ի���
class CMFCHtmlTest1Dlg : public CDialogEx
{
// ����
public:
	CMFCHtmlTest1Dlg(CWnd* pParent = NULL);	// ��׼���캯��

// �Ի�������
	enum { IDD = IDD_MFCHTMLTEST1_DIALOG };

protected:
	virtual void DoDataExchange(CDataExchange* pDX);	// DDX/DDV ֧��

// ʵ��
protected:
	DECLARE_MESSAGE_MAP()
	HICON m_hIcon;

	// ���ɵ���Ϣӳ�亯��
	virtual BOOL OnInitDialog();
	afx_msg void OnSysCommand(UINT nID, LPARAM lParam);
	afx_msg void OnPaint();
	afx_msg HCURSOR OnQueryDragIcon();
	afx_msg LRESULT OnInitData(WPARAM wParam, LPARAM lParam);
	afx_msg LRESULT OnClickCloseButton(WPARAM wParam, LPARAM lParam);
	afx_msg LRESULT OnClickMinimizeButton(WPARAM wParam, LPARAM lParam);
	afx_msg LRESULT OnJSMoveWindow(WPARAM wParam, LPARAM lParam);
	afx_msg LRESULT SetSlideIN(WPARAM wParam, LPARAM lParam);
	afx_msg LRESULT OnUpdataView(WPARAM wParam, LPARAM lParam);
public:
	CDemoHtmlView m_HtmlView;
	void UpdateView();
	afx_msg void OnSize(UINT nType, int cx, int cy);
	afx_msg HBRUSH OnCtlColor(CDC* pDC, CWnd* pWnd, UINT nCtlColor);
};
