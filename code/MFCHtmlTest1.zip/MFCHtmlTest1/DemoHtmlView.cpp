// DemoHtmlView.cpp : implementation file
//

#include "stdafx.h"
#include "MFCHtmlTest1.h"
#include "DemoHtmlView.h"
#include"Message.h"

// CDemoHtmlView

IMPLEMENT_DYNCREATE(CDemoHtmlView, CMyHtmlView)

BEGIN_MESSAGE_MAP(CDemoHtmlView, CMyHtmlView)
	ON_COMMAND(ID_FILE_PRINT, CMyHtmlView::OnFilePrint)
END_MESSAGE_MAP()


BEGIN_DISPATCH_MAP(CDemoHtmlView, CMyHtmlView)
	DISP_FUNCTION(CDemoHtmlView, "CloseWindow", CloseWindow, VT_EMPTY, VTS_NONE)
	DISP_FUNCTION(CDemoHtmlView, "MinimizeWindow", MinimizeWindow, VT_EMPTY, VTS_NONE)
	DISP_FUNCTION(CDemoHtmlView, "ClickCaption", ClickCaption, VT_EMPTY, VTS_WBSTR)
	DISP_FUNCTION(CDemoHtmlView, "slideIn", SetSlideIn, VT_EMPTY, VTS_I2)
	DISP_FUNCTION(CDemoHtmlView, "getLineData", getLineData, VT_EMPTY, VTS_WBSTR)
	DISP_FUNCTION(CDemoHtmlView, "getPieData", getPieData, VT_EMPTY, VTS_WBSTR)
	DISP_FUNCTION(CDemoHtmlView, "getThisDayData", getThisDayData, VT_EMPTY, VTS_WBSTR)
END_DISPATCH_MAP()

CDemoHtmlView::CDemoHtmlView()
{

}

CDemoHtmlView::~CDemoHtmlView()
{
}

// void CDemoHtmlView::DoDataExchange(CDataExchange* pDX)
// {
// 	CHtmlView::DoDataExchange(pDX);
// }



void CDemoHtmlView::OnInitialUpdate()
{
	CMyHtmlView::OnInitialUpdate();

	Navigate2(L"E:\\����\\MFCHtmlTest1\\MFCHtmlTest1\\IE2\\index.html", NULL, NULL);

}

void CDemoHtmlView::CloseWindow()
{
	::PostMessage(GetParent()->GetSafeHwnd(), WM_MAINJS_CLOSE, NULL, NULL);
	return;
}

void CDemoHtmlView::MinimizeWindow()
{
	::PostMessage(GetParent()->GetSafeHwnd(), WM_MAINJS_MINIMIZE, NULL, NULL);
	return;
}

void CDemoHtmlView::ClickCaption(LPCTSTR _bstr)
{
	::PostMessage(GetParent()->GetSafeHwnd(), WM_MAINJS_MOVE, (WPARAM)_bstr, NULL);
	return;
}

void CDemoHtmlView::SetSlideIn(short iShort)
{
	::PostMessage(GetParent()->GetSafeHwnd(), WM_MAINJS_SLIDEIN, (WPARAM)iShort, NULL);
	return;
}

void CDemoHtmlView::getLineData(LPCTSTR lpszLineData)
{
	int x = 1;
	return;
}

void CDemoHtmlView::getPieData(LPCTSTR lpszPieData)
{
	int x = 1;
	return;
}

void CDemoHtmlView::getThisDayData(LPCTSTR lpszDayData)
{
	int x = 1;
	return;
}

// CDemoHtmlView diagnostics

// #ifdef _DEBUG
// void CDemoHtmlView::AssertValid() const
// {
// 	CHtmlView::AssertValid();
// }
// 
// void CDemoHtmlView::Dump(CDumpContext& dc) const
// {
// 	CHtmlView::Dump(dc);
// }
// #endif //_DEBUG


// CDemoHtmlView message handlers


void CDemoHtmlView::OnDocumentComplete(LPCTSTR lpszURL)
{
	// TODO: Add your specialized code here and/or call the base class
	CMyHtmlView::OnDocumentComplete(lpszURL);
	
//	::PostMessage(GetParent()->GetSafeHwnd(), WM_UPDATAVIEW, NULL, NULL);
	::PostMessage(GetParent()->GetSafeHwnd(), WM_INITDATA, NULL, NULL);

//	SetSlideIn(0);



}
