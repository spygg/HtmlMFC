#pragma once
#define WM_MAINJS_CLOSE					(WM_APP + 200)
#define WM_MAINJS_MINIMIZE		        (WM_APP + 201)
#define WM_MAINJS_MOVE					(WM_APP + 202)
#define WM_MAINJS_SLIDEIN				(WM_APP + 203)