// BaseHtmlView.cpp : ʵ���ļ�
//

#include "stdafx.h"
#include "BaseHtmlView.h"


// CBaseHtmlView

IMPLEMENT_DYNCREATE(CBaseHtmlView, CHtmlView)

CBaseHtmlView::CBaseHtmlView()
{

}

CBaseHtmlView::~CBaseHtmlView()
{
}

void CBaseHtmlView::DoDataExchange(CDataExchange* pDX)
{
	CHtmlView::DoDataExchange(pDX);
}

BEGIN_MESSAGE_MAP(CBaseHtmlView, CHtmlView)
	ON_WM_MOUSEACTIVATE()
	ON_WM_DESTROY()
	ON_WM_SIZE()
END_MESSAGE_MAP()


// CBaseHtmlView ���

#ifdef _DEBUG
void CBaseHtmlView::AssertValid() const
{
	CHtmlView::AssertValid();
}

void CBaseHtmlView::Dump(CDumpContext& dc) const
{
	CHtmlView::Dump(dc);
}
#endif //_DEBUG


// CBaseHtmlView ��Ϣ��������


void CBaseHtmlView::PostNcDestroy()
{
	// TODO: �ڴ�����ר�ô����/����û���

	//CWnd::PostNcDestroy();
}


int CBaseHtmlView::OnMouseActivate(CWnd* pDesktopWnd, UINT nHitTest, UINT message)
{
	// TODO: �ڴ�������Ϣ������������/�����Ĭ��ֵ

	return CWnd::OnMouseActivate(pDesktopWnd, nHitTest, message);
}


void CBaseHtmlView::OnDestroy()
{
	if (m_pBrowserApp)
	{
		m_pBrowserApp.Release();
		m_pBrowserApp = NULL;
	}
	CWnd::OnDestroy();

	// TODO: �ڴ˴�������Ϣ�����������
}


void CBaseHtmlView::OnSize(UINT nType, int cx, int cy)
{
	CHtmlView::OnSize(nType, cx, cy);

	// TODO: �ڴ˴�������Ϣ�����������
	if (::IsWindow(m_wndBrowser.m_hWnd))
	{
		CRect rect;
		GetClientRect(rect);
		LONG lWindows = GetWindowLong(GetParent()->GetSafeHwnd(), GWL_EXSTYLE);
		/*		::AdjustWindowRectEx(rect, GetStyle(), FALSE, WS_CLIPSIBLINGS);*/
		::AdjustWindowRectEx(rect, GetStyle(), FALSE, lWindows);

		m_wndBrowser.SetWindowPos(NULL, rect.left, rect.top, 962, 632, SWP_NOACTIVATE | SWP_NOZORDER);

	}
}


void CBaseHtmlView::OnInitialUpdate()
{
	CHtmlView::OnInitialUpdate();

	// TODO: �ڴ�����ר�ô����/����û���
	//Navigate2(L"http://blog.csdn.net/qq_20828983?viewmode=contents", NULL, NULL);
	Navigate2(L"E:\\����\\CHTMLDome2\\IE2\\index.html", NULL, NULL);
}


void CBaseHtmlView::OnDocumentComplete(LPCTSTR lpszURL)
{
	// TODO: �ڴ�����ר�ô����/����û���
// 	CRect rect;
// 	GetParent()->GetWindowRect(&rect);
// 	::MoveWindow(GetSafeHwnd(), 0, 0, 600, 300, TRUE);
	CHtmlView::OnDocumentComplete(lpszURL);
	SetScriptDocument(); //��ʼ��com��� IID_IHTMLDocument2�ӿ�

	::PostMessage(GetParent()->GetSafeHwnd(), WM_MAINJS_INITDATA, NULL, NULL);
}

BOOL CBaseHtmlView::CreateFromStatic(UINT nID, CWnd* pParent)
{
	CWnd* pStatic = pParent->GetDlgItem(nID);
	if (pStatic == NULL)
		return FALSE;

	CRect rc;
	pStatic->GetWindowRect(&rc);
	pParent->ScreenToClient(&rc);
	pStatic->DestroyWindow();

	if (!CHtmlView::Create(NULL, NULL, (WS_CHILD | WS_VISIBLE), rc, pParent, nID, NULL))
		return FALSE;

	OnInitialUpdate(); //����URL
	SetSilent(TRUE);//add by wh ,bid pop script dlg  true��ʾ����JaveScript���浯���Ի���
	return TRUE;
}

BOOL CBaseHtmlView::SetScriptDocument()
{
	CComPtr<IDispatch> spDisp = GetHtmlDocument(); //��ȡcom ��ʼ�ӿ�ָ��
	if (spDisp == NULL)
	{
		ASSERT(FALSE);
		return FALSE;
	}

	m_spDoc = NULL;
	HRESULT hr = spDisp->QueryInterface(IID_IHTMLDocument2, (void **)&m_spDoc);
	if (FAILED(hr))
	{
		MessageBox(L"Failed to get HTML document COM object");
		return FALSE;
	}

	return TRUE;
}

BOOL CBaseHtmlView::GetJScript(CComPtr<IDispatch>& spDisp)
{
	if (m_spDoc == NULL)
		return FALSE;

	HRESULT hr = m_spDoc->get_Script(&spDisp); //��ȡScript�ӿ�
	ATLASSERT(SUCCEEDED(hr));
	return SUCCEEDED(hr);
}

const CString CBaseHtmlView::GetSystemErrorMessage(DWORD dwError)
{
	CString strError;
	LPTSTR lpBuffer;

	if (!FormatMessage(FORMAT_MESSAGE_ALLOCATE_BUFFER | FORMAT_MESSAGE_FROM_SYSTEM,
		NULL, dwError,
		MAKELANGID(LANG_NEUTRAL, SUBLANG_SYS_DEFAULT),
		(LPTSTR)&lpBuffer, 0, NULL))
	{
		strError = "FormatMessage Netive Error";
	}
	else
	{
		strError = lpBuffer;
		LocalFree(lpBuffer);
	}
	return strError;
}

BOOL CBaseHtmlView::CallJScript(const CString strFunc, const CStringArray& paramArray, _variant_t* pVarResult /*= NULL*/)
{
	CComPtr<IDispatch> spScript;
	if (!GetJScript(spScript))
	{
		MessageBox(L"����GetJScrip����ʧ�ܣ�");
		return FALSE;
	}

	CComBSTR bstrFunc(strFunc);
	DISPID dispid = NULL;
	//��������strFunc ��ȡ ids
	HRESULT hr = spScript->GetIDsOfNames(IID_NULL, &bstrFunc, 1, LOCALE_SYSTEM_DEFAULT, &dispid);
	if (FAILED(hr))
	{
		MessageBox(GetSystemErrorMessage(hr));
		return FALSE;
	}

	DISPPARAMS dispparams;
	memset(&dispparams, 0, sizeof dispparams);

	INT_PTR arraySize = paramArray.GetSize();
	dispparams.cArgs = (UINT)arraySize; //��������
	dispparams.rgvarg = new VARIANT[dispparams.cArgs]; 

	for (int i = 0; i < arraySize; i++)
	{
		CComBSTR bstr = paramArray.GetAt(arraySize - 1 - i); // back reading
		bstr.CopyTo(&dispparams.rgvarg[i].bstrVal);
		dispparams.rgvarg[i].vt = VT_BSTR;
	}
	dispparams.cNamedArgs = 0;

	EXCEPINFO excepInfo;
	memset(&excepInfo, 0, sizeof excepInfo);
	_variant_t vaResult;
	UINT nArgErr = (UINT)-1;  // initialize to invalid arg

	//����JaveScript�ӿ�
	hr = spScript->Invoke(dispid, IID_NULL, 0,
		DISPATCH_METHOD, &dispparams, &vaResult, &excepInfo, &nArgErr);
	
	delete[] dispparams.rgvarg;
	if (FAILED(hr))
	{
		MessageBox(GetSystemErrorMessage(hr));
		return FALSE;
	}

	if (pVarResult)
	{
		*pVarResult = vaResult;
	}
	return TRUE;
}

BOOL CBaseHtmlView::CallJScript(const CString strFunc, _variant_t* pVarResult /*= NULL*/)
{
	CStringArray paramArray;
	return CallJScript(strFunc, paramArray, pVarResult);
}

BOOL CBaseHtmlView::CallJScript(const CString strFunc, const CString strArg1, _variant_t* pVarResult /*= NULL*/)
{
	CStringArray paramArray;
	paramArray.Add(strArg1);
	return CallJScript(strFunc, paramArray, pVarResult);
}

BOOL CBaseHtmlView::CallJScript(const CString strFunc, const CString strArg1, const CString strArg2, _variant_t* pVarResult /*= NULL*/)
{
	CStringArray paramArray;
	paramArray.Add(strArg1);
	paramArray.Add(strArg2);
	return CallJScript(strFunc, paramArray, pVarResult);
}

BOOL CBaseHtmlView::CallJScript(const CString strFunc, const CString strArg1, const CString strArg2, const CString strArg3, _variant_t* pVarResult /*= NULL*/)
{
	CStringArray paramArray;
	paramArray.Add(strArg1);
	paramArray.Add(strArg2);
	paramArray.Add(strArg3);
	return CallJScript(strFunc, paramArray, pVarResult);
}


BOOL CBaseHtmlView::CreateControlSite(COleControlContainer* pContainer, COleControlSite** ppSite, UINT nID, REFCLSID clsid)
{
	*ppSite = new CDocHostSite(pContainer, this);// �����Լ��Ŀ���վ��ʵ��

	return (*ppSite) ? TRUE : FALSE;
}

HRESULT CBaseHtmlView::OnGetDropTarget(LPDROPTARGET pDropTarget, LPDROPTARGET* ppDropTarget)
{
	m_DropTarget.SetIEDropTarget(pDropTarget);

	LPDROPTARGET pMyDropTarget;
	pMyDropTarget = (LPDROPTARGET)m_DropTarget.GetInterface(&IID_IDropTarget);
	if (pMyDropTarget)
	{
		*ppDropTarget = pMyDropTarget;
		pMyDropTarget->AddRef();
		return S_OK;
	}

	return S_FALSE;
}

HRESULT CBaseHtmlView::OnGetHostInfo(DOCHOSTUIINFO * pInfo)
{
	pInfo->cbSize = sizeof(DOCHOSTUIINFO);
	pInfo->dwFlags = DOCHOSTUIFLAG_THEME | DOCHOSTUIFLAG_NO3DBORDER;
	pInfo->dwDoubleClick = DOCHOSTUIDBLCLK_DEFAULT;

	return S_OK;
}


HRESULT CBaseHtmlView::OnGetExternal(LPDISPATCH *lppDispatch)
{
	*lppDispatch = GetIDispatch(TRUE);
	return S_OK;
}

HRESULT CBaseHtmlView::OnShowMessage(HWND hwnd, LPOLESTR lpstrText, LPOLESTR lpstrCaption, DWORD dwType, LPOLESTR lpstrHelpFile, DWORD dwHelpContext, LRESULT * plResult)
{
	// ���ڱ���"Microsoft Internet Explorer"����Դ��ʶ
#define IDS_MESSAGE_BOX_TITLE 2213
	//����Shdoclc.dll ��IE��Ϣ������ַ���
	HINSTANCE hinstSHDOCLC = LoadLibrary(TEXT("SHDOCLC.DLL"));
	if (hinstSHDOCLC == NULL)
		return S_FALSE;

	CString strBuf, strCaption(lpstrCaption);
	strBuf.LoadString(hinstSHDOCLC, IDS_MESSAGE_BOX_TITLE);

	// �Ƚ�IE��Ϣ������ַ�����lpstrCaption
	// �����ͬ�����Զ�������滻
	if (strBuf == lpstrCaption)
		strCaption = "LHP HTMLVIEW";

	// �����Լ�����Ϣ������ʾ
	*plResult = MessageBox(CString(lpstrText), strCaption, dwType);

	//ж��Shdoclc.dll���ҷ���
	FreeLibrary(hinstSHDOCLC);

	return S_OK;
}